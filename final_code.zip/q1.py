import q1ab as ab
import q1c as c
import q1d as d
import q1e as e


def execute():
    text_files = ['A.txt', 'B.txt', 'C.txt', 'D.txt', 'E.txt']
    # Remove punctuation and stop words, remove words common between all 5 files
    cleaned_text = ab.clean_files(text_files)

    # Clean the test file x.txt
    clean_x = ab.clean_file('X.txt')
    c.show_common(cleaned_text, clean_x)
    d.show_common_long(cleaned_text, clean_x)
    e.show_common_unusual(cleaned_text, clean_x)
