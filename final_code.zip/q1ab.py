import string
import nltk
from collections import Counter

# nltk.download('stopwords')


def remove_punctuation(text):
    text = text.translate(str.maketrans('', '', '“”’'))
    return text.translate(str.maketrans('', '', string.punctuation))


def remove_stop_words(text):
    stop_words = set(nltk.corpus.stopwords.words('english'))
    text_tokenized = nltk.word_tokenize(text)
    return [w for w in text_tokenized if w not in stop_words]


def remove_common(text_lists):
    s = []   # text_sets, renamed to s out of laziness
    for t_list in text_lists:
        text_set = set(t_list)
        s.append(text_set)

    # Get all of the words common to all 5 files
    intersections = s[0].intersection(s[1].intersection(s[2].intersection(s[3].intersection(s[4]))))
    for i in intersections:
        for j in text_lists:
            if i in j:
                j.remove(i)
    return text_lists


def clean_files(text_files):
    clean_text_files = []
    text_counters = []
    for i in text_files:
        with open(i) as file:
            text = file.read().lower()
            text = remove_punctuation(text)
            text = remove_stop_words(text)
            clean_text_files.append(text)

    text_no_commons = remove_common(clean_text_files)
    return text_no_commons


def clean_file(text_file):
    with open(text_file) as file:
        text = file.read().lower()
        text = remove_punctuation(text)
        text = remove_stop_words(text)
        return text

if __name__ == "__main__":
    text_files = ['A.txt', 'B.txt', 'C.txt', 'D.txt', 'E.txt']
    clean_text_files = []
    text_counters = []
    for i in text_files:
        with open(i) as file:
            text = file.read().lower()
            text = remove_punctuation(text)
            text = remove_stop_words(text)
            clean_text_files.append(text)

    for i in clean_text_files:
        print(len(i))

    text_no_commons = remove_common(clean_text_files)
    print("Cleaned text")
    for i in text_no_commons:
        print(len(i))