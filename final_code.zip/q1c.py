import matplotlib.pyplot as plt
import statistics


def show_common(known_text, unknown_text):
    common_word_counts = []
    for i in known_text:
        similar_words = len(set(unknown_text).intersection(set(i)))
        common_word_counts.append(similar_words)
    text_names = ['A.txt', 'B.txt', 'C.txt', 'D.txt', 'E.txt']

    word_mean = statistics.mean(common_word_counts)
    word_std = statistics.stdev(common_word_counts, word_mean)
    print("Mean:", word_mean)
    print("Standard Deviation:", word_std)
    two_std = word_std * 2
    for index, i in enumerate(common_word_counts):
        if abs(i-word_mean) > two_std:
            print(text_names[index] + " is more than two standard deviations away.")
        else:
            print(text_names[index] + " is within two standard deviations of the mean.")

    plt.bar(text_names, common_word_counts)
    plt.title("Common words with X.txt")
    plt.xlabel("File Name")
    plt.ylabel("Common Words")
    plt.show()

