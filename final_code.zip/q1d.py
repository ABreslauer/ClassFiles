import q1c as c


def show_common_long(known_text, unknown_text):
    for index, i in enumerate(known_text):
        known_text[index] = [x for x in set(i) if len(x) > 12]  # let's see how many 12+ words there are
    c.show_common(known_text, unknown_text)
