import q1c as c
from collections import Counter


def show_common_unusual(known_text, unknown_text):
    counters = []
    for i in known_text:
        counters.append(Counter(i))
    counter_x = Counter(unknown_text)
    filtered_x_words = [k for k, v in counter_x.items() if v <= 1]
    filtered_known_words = []
    for i in counters:
        filtered_known_words.append([k for k, v in i.items() if v <= 1])
    c.show_common(filtered_known_words, filtered_x_words)
