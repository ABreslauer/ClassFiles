import q2part1a as part1a
import q2part1b as part1b
import q2part2e as part2e
import q2part2f as part2f


def execute():
    with open("e3facts.corp.txt") as file:
        text = file.read()
    text = part1a.replace_to_know(text)
    part1b.buildn3(text)  # writes to data.n3
    with open("e3slang.commas.txt") as file:
        text_slang = file.read()
    with open("e3tweets.txt") as file:
        text_tweets = file.read()
    tweets = part2e.replace_slang(text_tweets, text_slang)
    part2f.nltk_chunker(tweets)

