import nltk
import re
from nltk.tokenize import sent_tokenize, word_tokenize
# nltk.download('punkt')
# nltk.download('averaged_perceptron_tagger')


def replace_to_know(text):
    sentences = nltk.sent_tokenize(text)
    for index, i in enumerate(sentences):
        known_phrases = "plays pingpong with |plays baseball with |dances with |talks to "  # only instances of knowing
        i = re.sub(known_phrases, "knows ", i)
        sentences[index] = i
    return sentences
