import nltk
import re


def buildn3(text):
    tag_list = []
    for i in text:
        words = nltk.word_tokenize(i)
        word_tags = nltk.pos_tag(words)
        tags = []
        for j in word_tags:
            tags.append(j[1])
        tag_list.append(tags)

    joined_phrases = []
    for i in text:
        joined_phrases.append(nltk.pos_tag(i.split()))

    locations = []
    companies = []
    company_locations = []
    people = []
    work_relations = []
    people_relations = []

    for i in joined_phrases:
        if i[2][1] == "VBN":
            locations.append(i[4][0][:-1])
            companies.append(i[0][0])
            company_locations.append((i[0][0], i[4][0][:-1]))
        if i[2][1] == "IN":
            companies.append(i[-1][0][:-1])
            work_relations.append((i[0][0], i[-1][0][:-1]))
            people.append(i[0][0])
        if i[0][1] == "NNP" and i[2][1] == "NNP":
            people_relations.append((i[0][0], i[2][0][:-1]))
    for i in people_relations:
        people.append(i[0])
        people.append(i[1])
    with open("data.n3", 'w') as outfile:
        outfile.write("""@prefix :  <http://www.lyle.smu.edu//#> .
@prefix rdf:  <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#>.
@prefix schema: <http://schema.org/> .
@prefix owl:    <http://www.w3.org/2002/07/owl#> .\n\n""")
        for i in list(set(locations)):  # list(set(list)) clears duplicates
            outstring = ":" + i + " rdf:type schema:Location .\n"
            outfile.write(outstring)
        for i in list(set(companies)):
            outstring = ":" + i + " rdf:type schema:Organization .\n"
            outfile.write(outstring)
        for i in list(set(company_locations)):
            outstring = ":" + i[0] + " schema:Location :" + i[1] + ".\n"
            outfile.write(outstring)
        for i in list(set(people)):
            outstring = ":" + i + " rdf:type schema:Person .\n"
            outfile.write(outstring)
        for i in people_relations:
            outstring = ":" + i[0] + " schema:knows :" + i[1] + " .\n"
            outfile.write(outstring)
            outstring = ":" + i[1] + " schema:knows :" + i[0] + " .\n"
            outfile.write(outstring)
        for i in work_relations:
            outstring = ":" + i[0] + " schema:worksFor :" + i[1] + " .\n"
            outfile.write(outstring)
            company_loc = [x for j, x in company_locations if j == i[1]]
            if company_loc:
                outstring = ":" + i[0] + " schema:homeLocation :" + company_loc[0] + " .\n"
                outfile.write(outstring)