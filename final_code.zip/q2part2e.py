import re


def replace_slang(text_tweets, text_slang):
    positive_slang = []
    negative_slang = []
    for i in text_slang.split('\n'):
        if i.split(",")[0] == "aight":
            positive_slang = i.split(",")
        elif i.split(",")[0] == "404":
            negative_slang = i.split(",")
    positive_string = ""
    negative_string = ""
    negative_slang.pop()                        # For some reason there is an extra space on the end
    for index, i in enumerate(positive_slang):  # Doing this because it makes sense in my head for regex sub
        if index == len(positive_slang)-1:      # Assemble the full string rather than going word by word
            positive_string += i+''
        else:
            positive_string += i + '|'
    for index, i in enumerate(negative_slang):
        if index == len(negative_slang)-1:
            negative_string += i + ''
        else:
            negative_string += i + '|'

    tweets = []
    tweets_split = text_tweets.split('\n')
    for index, i in enumerate(tweets_split):
        if list(i) and len(i.split()) > 1:  # If there is any content with more than word/not the lines with names
            tweets.append([tweets_split[index-1][:-1], i])  # Attach tweets with the person that said them
    for index, i in enumerate(tweets):
        tweets[index][1] = re.sub(positive_string, "good ", i[1])
        tweets[index][1] = re.sub(negative_string, "bad ", i[1])
    return tweets
