import nltk
import re
import e3code as e3


def nltk_chunker(tweets):
    nltk_tweets = []
    for i in tweets:
        nltk_mixed = nltk.pos_tag(i[1].split())
        nltk_tweets.append([v for k, v in nltk_mixed])

    opinion_tweet = []
    for index, i in enumerate(nltk_tweets):
        search = re.findall('.*?NNP.*?V..?.*?J..?', ' '.join(i))
        if search:
            curr_tweet = tweets[index]
            opinion_tweet.append((tweets[index][0], curr_tweet[1]))

    triples = []
    for i in opinion_tweet:
        lebron_index = i[1].split().index("Labron")
        triples.append([i[0], i[1].split()[lebron_index+2], "Labron"])
        titanic_index = i[1].split().index("Titanic")
        triples.append([i[0], i[1].split()[titanic_index+2], "Titanic"])

    with open("data.n3", "a+") as outfile:
        for i in triples:
            if i[1] == "bad":
                if i[2] == "Labron":
                    outstring = ":" + i[0] + " :dislikes :Lakers.\n"
                    outfile.write(outstring)
                outstring = ":" + i[0] + " :dislikes :" + i[2] + ".\n"
                outfile.write(outstring)
            elif i[1] == "good":
                outstring = ":" + i[0] + " :likes :" + i[2] + ".\n"
                outfile.write(outstring)
